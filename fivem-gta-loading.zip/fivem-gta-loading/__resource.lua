--
-- Author bt0r
-- Twitch : bt0r
-- Twitter : biiitor
--
files {
    'files/loader.html',
    'files/js/loader.js',
    'files/css/loader.css',
    'files/sound/intro.ogg',
    'files/img/background/1.jpg',
    'files/img/background/2.jpg',
    'files/img/background/3.jpg',
    'files/img/background/4.jpg',
    'files/img/background/5.jpg',
    'files/img/background/6.jpg',
    'files/img/background/7.jpg',
    'files/img/background/8.jpg',
    'files/img/background/9.jpg',
    'files/img/background/10.jpg',
    'files/img/background/11.jpg',
    'files/img/background/12.jpg',
    'files/img/background/13.jpg',
    'files/img/characters/1.png',
    'files/img/characters/2.png',
    'files/img/characters/3.png',
    'files/img/characters/4.png',
    'files/img/characters/5.png',
    'files/img/characters/6.png',
    'files/img/characters/7.png',
    'files/img/characters/8.png',
    'files/img/characters/9.png',
    'files/img/characters/10.png',
    'files/img/characters/11.png',
    'files/img/characters/12.png',
    'files/img/characters/13.png',
    'files/img/characters/14.png',
    'files/img/characters/15.png',
    'files/img/characters/16.png',	
    'files/img/logo.png'
}

loadscreen 'files/loader.html'

-- Tell server we will close the loading screen resource ourselfs
loadscreen_manual_shutdown "yes"
-- Client Script
client_script "client.lua"